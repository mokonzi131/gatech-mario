package dk.itu.mario.res;

public class ResourcesManager {
    private ResourcesManager() {
    }
}
